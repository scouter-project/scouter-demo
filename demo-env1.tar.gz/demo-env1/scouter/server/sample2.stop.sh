#!/usr/bin/env bash

. $(dirname $0)/env.sh

rm -f "$TUNAHOME/*.scouter"
