cd ./jmeter/bin
./jmeter.sh -n -t scouter-demo1.jmx
cd ../..
