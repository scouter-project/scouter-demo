cd ./apache-tomcat-7.0.67/bin
./startup.sh
cd ../..
