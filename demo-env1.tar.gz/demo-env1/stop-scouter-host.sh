cd ./scouter/agent.host
stop.sh
cd ../..
