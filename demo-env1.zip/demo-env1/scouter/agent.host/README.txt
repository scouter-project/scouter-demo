Scouter Host Agent includes : 
 Sigar
 Visit the SIGAR Wiki for documentation, bugs, support, etc.:
 http://sigar.hyperic.com/
 Copyright (c) 2006 Hyperic, Inc.
 Copyright (c) 2010 VMware, Inc.
 
 http://www.apache.org/licenses/LICENSE-2.0