#!/usr/bin/env bash
java -Xmx512m -cp boot.jar scouter.boot.Boot ./lib -console

