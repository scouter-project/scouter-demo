cd ./scouter/server
startup.sh
cd ../..
